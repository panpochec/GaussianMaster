GaussianMaster is here!

aussianMaster Package is a modest Python3.X package allowing faster and more automated extraction
and manipulation on data from Gaussian calculations. It currently supports extraction form results of
optimalization and modredundant (scan) runs. The detailed description of the contents is presented
on:
https://github.com/panpochec/GaussianMaster

You can contact me directly using lysy.pochec@gmail.com

Have fun!
And may the odds be ever in your favour